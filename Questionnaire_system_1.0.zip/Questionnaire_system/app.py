from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
from database import db, User, Survey, Question, Option, Response, SurveyResponse
from werkzeug.security import generate_password_hash, check_password_hash
from io import BytesIO

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///survey.db'
db.init_app(app)

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        if role == 'teacher' and request.form['invite_code'] != '123456':
            flash('教师邀请码错误')
            return redirect(url_for('register'))
            
        if User.query.filter_by(username=username).first():
            flash('用户名已存在')
            return redirect(url_for('register'))
            
        user = User(
            username=username,
            password=generate_password_hash(password),
            role=role
        )
        db.session.add(user)
        db.session.commit()
        
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['role'] = user.role
            return redirect(url_for('dashboard'))
            
        flash('用户名或密码错误')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if session['role'] == 'teacher':
        surveys = Survey.query.filter_by(teacher_id=session['user_id']).all()
        return render_template('teacher/dashboard.html', surveys=surveys)
    else:
        # 获取所有问卷
        surveys = Survey.query.filter_by(is_active=True).all()
        # 获取学生的答卷历史
        responses = SurveyResponse.query.filter_by(student_id=session['user_id']).order_by(SurveyResponse.submitted_at.desc()).all()
        return render_template('student/dashboard.html', 
                             surveys=surveys,
                             responses=responses)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# 教师相关路由
@app.route('/create_survey', methods=['GET', 'POST'])
def create_survey():
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        try:
            # 获取表单数据
            title = request.form.get('title')
            if not title:
                flash('问卷标题不能为空')
                return redirect(url_for('create_survey'))

            # 创建问卷
            survey = Survey(
                title=title,
                teacher_id=session['user_id']
            )
            db.session.add(survey)
            db.session.commit()
            
            # 处理问题和选项
            questions = request.form.getlist('questions[]')
            question_types = request.form.getlist('question_types[]')
            
            if not questions:
                flash('至少需要添加一问题')
                return redirect(url_for('create_survey'))
                
            for i, (q_text, q_type) in enumerate(zip(questions, question_types)):
                if not q_text.strip():
                    continue
                    
                question = Question(
                    survey_id=survey.id,
                    question_text=q_text,
                    question_type=q_type,
                    order=i+1
                )
                db.session.add(question)
                db.session.commit()
                
                # 如果是选择题（单选或多选），则添加选项
                if q_type in ['single', 'multiple']:
                    options = request.form.getlist(f'options[{i}][]')
                    if not options:
                        print(f"No options found for question {i}")
                        continue
                        
                    for j, opt_text in enumerate(options):
                        if not opt_text.strip():
                            continue
                            
                        option = Option(
                            question_id=question.id,
                            option_text=opt_text.strip(),
                            order=j+1
                        )
                        db.session.add(option)
            
            db.session.commit()
            flash('问卷创建成功！')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            db.session.rollback()
            flash('创建问卷失败，请检查输入数据是否正确')
            print(f"Error creating survey: {str(e)}")  # 记录错误信息
            return redirect(url_for('create_survey'))
        
    return render_template('teacher/create_survey.html')

@app.route('/edit_survey/<int:survey_id>', methods=['GET', 'POST'])
def edit_survey(survey_id):
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect(url_for('login'))
        
    survey = Survey.query.get_or_404(survey_id)
    if survey.teacher_id != session['user_id']:
        flash('您没有权限编辑此问卷')
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        try:
            # 更新问卷基本信息
            title = request.form.get('title')
            if not title:
                flash('问卷标题不能为空')
                return redirect(url_for('edit_survey', survey_id=survey_id))
                
            survey.title = title
            survey.is_active = 'is_active' in request.form
            
            # 获取新的问题和选项数据
            questions = request.form.getlist('questions[]')
            question_types = request.form.getlist('question_types[]')
            
            if not questions:
                flash('至少需要添加一个问题')
                return redirect(url_for('edit_survey', survey_id=survey_id))
            
            # 删除所有现有的问题和选项
            for question in survey.questions:
                Option.query.filter_by(question_id=question.id).delete()
            Question.query.filter_by(survey_id=survey.id).delete()
            db.session.commit()
            
            # 添加新的问题和选项
            for i, (q_text, q_type) in enumerate(zip(questions, question_types)):
                if not q_text.strip():
                    continue
                    
                question = Question(
                    survey_id=survey.id,
                    question_text=q_text,
                    question_type=q_type,
                    order=i+1
                )
                db.session.add(question)
                db.session.commit()
                
                # 获取该问题的选项
                if q_type in ['single', 'multiple']:
                    options = request.form.getlist(f'options[{i}][]')
                    if not options:
                        print(f"No options found for question {i}")  # 调试信息
                        continue
                        
                    for j, opt_text in enumerate(options):
                        if not opt_text.strip():
                            continue
                            
                        option = Option(
                            question_id=question.id,
                            option_text=opt_text.strip(),
                            order=j+1
                        )
                        db.session.add(option)
                        print(f"Added option: {opt_text} for question {i}")  # 调试信息
            
            db.session.commit()
            flash('问卷更新成功！')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            db.session.rollback()
            flash('更新问卷失败，请检查输入数据是否正确')
            print(f"Error updating survey: {str(e)}")  # 记录错误信息
            return redirect(url_for('edit_survey', survey_id=survey_id))
        
    return render_template('teacher/edit_survey.html', survey=survey)

@app.route('/view_responses/<int:survey_id>')
def view_responses(survey_id):
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect(url_for('login'))
        
    survey = Survey.query.get_or_404(survey_id)
    if survey.teacher_id != session['user_id']:
        flash('您没有权限查看此问卷的答卷')
        return redirect(url_for('dashboard'))
        
    # 获取所有的答卷记录
    survey_responses = SurveyResponse.query.filter_by(survey_id=survey_id).all()
    
    return render_template('teacher/view_responses.html', 
                         survey=survey, 
                         survey_responses=survey_responses)

# 学生相关路由
@app.route('/take_survey/<int:survey_id>', methods=['GET', 'POST'])
def take_survey(survey_id):
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
        
    survey = Survey.query.get_or_404(survey_id)
    if not survey.is_active:
        flash('此问卷已关闭')
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        # 创建问卷提交记录
        survey_response = SurveyResponse(
            student_id=session['user_id'],
            survey_id=survey_id
        )
        db.session.add(survey_response)
        
        # 保存每个问题的答案
        for question in survey.questions:
            if question.question_type == 'text':
                # 处理文本答案
                text_answer = request.form.get(f'question_{question.id}_text')
                if text_answer:
                    response = Response(
                        student_id=session['user_id'],
                        survey_id=survey_id,
                        question_id=question.id,
                        text_answer=text_answer
                    )
                    db.session.add(response)
            elif question.question_type == 'multiple':
                # 处理多选答案
                option_ids = request.form.getlist(f'question_{question.id}')
                for option_id in option_ids:
                    response = Response(
                        student_id=session['user_id'],
                        survey_id=survey_id,
                        question_id=question.id,
                        option_id=int(option_id)
                    )
                    db.session.add(response)
            else:
                # 处理单选答案
                option_id = request.form.get(f'question_{question.id}')
                if option_id:
                    response = Response(
                        student_id=session['user_id'],
                        survey_id=survey_id,
                        question_id=question.id,
                        option_id=int(option_id)
                    )
                    db.session.add(response)
                
        db.session.commit()
        flash('问卷提交成功！')
        return redirect(url_for('dashboard'))
        
    return render_template('student/take_survey.html', survey=survey)

@app.route('/view_response/<int:response_id>')
@app.route('/view_response/<int:response_id>/<string:return_to>')
def view_response(response_id, return_to='dashboard'):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    survey_response = SurveyResponse.query.get_or_404(response_id)
    
    # 检查权限
    if (session['role'] == 'student' and survey_response.student_id != session['user_id']) or \
       (session['role'] == 'teacher' and survey_response.survey.teacher_id != session['user_id']):
        flash('您没有权限查看此答卷')
        return redirect(url_for('dashboard'))
        
    responses = Response.query.filter_by(
        student_id=survey_response.student_id,
        survey_id=survey_response.survey_id
    ).all()
    
    return render_template('view_response.html', 
                         survey_response=survey_response,
                         responses=responses,
                         return_to=return_to)

@app.route('/survey_statistics/<int:survey_id>')
def survey_statistics(survey_id):
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect(url_for('login'))
        
    survey = Survey.query.get_or_404(survey_id)
    if survey.teacher_id != session['user_id']:
        flash('您没有权限查看此问卷的统计数据')
        return redirect(url_for('dashboard'))
    
    # 将问题对象转换为字典
    questions_data = [{
        'id': q.id,
        'text': q.question_text,
        'order': q.order
    } for q in sorted(survey.questions, key=lambda x: x.order)]
    
    stats = survey.get_statistics()
    return render_template('teacher/survey_statistics.html', 
                         survey=survey,
                         questions=questions_data,
                         stats=stats)

@app.route('/export_survey/<int:survey_id>')
def export_survey(survey_id):
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect(url_for('login'))
        
    survey = Survey.query.get_or_404(survey_id)
    if survey.teacher_id != session['user_id']:
        flash('您没有权限导出此问卷的数据')
        return redirect(url_for('dashboard'))
    
    # 生成Excel文件
    wb = survey.to_excel()
    
    # 保存到内存中
    excel_file = BytesIO()
    wb.save(excel_file)
    excel_file.seek(0)
    
    return send_file(
        excel_file,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'{survey.title}-统计数据.xlsx'
    )

@app.route('/api/survey_stats/<int:survey_id>')
def api_survey_stats(survey_id):
    """获取问卷统计数据的API接口，用于图表展示"""
    if 'user_id' not in session or session['role'] != 'teacher':
        return jsonify({'error': '未授权'}), 401
        
    survey = Survey.query.get_or_404(survey_id)
    if survey.teacher_id != session['user_id']:
        return jsonify({'error': '无权限'}), 403
    
    stats = survey.get_statistics()
    return jsonify(stats)

@app.route('/delete_survey/<int:survey_id>', methods=['POST'])
def delete_survey(survey_id):
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect(url_for('login'))
        
    survey = Survey.query.get_or_404(survey_id)
    if survey.teacher_id != session['user_id']:
        flash('您没有权限删除此问卷')
        return redirect(url_for('dashboard'))
        
    try:
        # 删除问卷相关的所有数据
        Response.query.filter_by(survey_id=survey_id).delete()
        SurveyResponse.query.filter_by(survey_id=survey_id).delete()
        for question in survey.questions:
            Option.query.filter_by(question_id=question.id).delete()
        Question.query.filter_by(survey_id=survey_id).delete()
        db.session.delete(survey)
        db.session.commit()
        flash('问卷删除成功！')
    except Exception as e:
        db.session.rollback()
        flash('删除问卷失败')
        print(f"Error deleting survey: {str(e)}")
        
    return redirect(url_for('dashboard'))

@app.route('/toggle_survey_status/<int:survey_id>', methods=['POST'])
def toggle_survey_status(survey_id):
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect(url_for('login'))
        
    survey = Survey.query.get_or_404(survey_id)
    if survey.teacher_id != session['user_id']:
        flash('您没有权限修改此问卷')
        return redirect(url_for('dashboard'))
        
    try:
        survey.is_active = not survey.is_active
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash('状态更新失败')
        print(f"Error updating survey status: {str(e)}")
        
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)